<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = htmlspecialchars($_POST['firstname']);
    $lastname = htmlspecialchars($_POST['lastname']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $gender = htmlspecialchars($_POST['gender']);
    $birthdate = htmlspecialchars($_POST['birthdate']);
} else {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation des données</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #121212;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #1e1e1e;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #fff;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .input-group {
            display: flex;
            align-items: center;
            background: #2a2a2a;
            border-radius: 8px;
            margin-bottom: 15px;
            padding: 10px;
        }
        .input-group i {
            color: #bbb;
            margin-right: 10px;
            font-size: 16px;
        }
        .input-group input, .input-group select {
            width: 100%;
            border: none;
            background: transparent;
            color: #ddd;
            font-size: 16px;
            outline: none;
        }
        .input-group input::placeholder {
            color: #888;
        }
        .input-group select {
            appearance: none;
            cursor: pointer;
        }
        .input-group select option {
            color: black;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #444;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            font-weight: 600;
            transition: 0.3s;
        }
        button:hover {
            background: #666;
        }
        .confirmation-message {
            display: none;
            margin-top: 20px;
            padding: 10px;
            background:rgb(167, 85, 40);
            border-radius: 8px;
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Confirmation form</h2>
        <form id="confirmationForm">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="firstname" value="<?= $firstname ?>" required readonly>
            </div>

            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="lastname" value="<?= $lastname ?>" required readonly>
            </div>

            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" value="<?= $email ?>" required readonly>
            </div>

            <div class="input-group">
                <i class="fas fa-phone"></i>
                <input type="tel" name="phone" value="<?= $phone ?>" pattern="^\d{10}$" required readonly>
            </div>

            <div class="input-group">
                <i class="fas fa-venus-mars"></i>
                <select name="gender" required disabled>
                    <option value="Male" <?= ($gender == "Male") ? "selected" : "" ?>>Male</option>
                    <option value="Female" <?= ($gender == "Female") ? "selected" : "" ?>>Female</option>
                    <option value="Other" <?= ($gender == "Other") ? "selected" : "" ?>>Other</option>
                </select>
            </div>

            <div class="input-group">
                <i class="fas fa-calendar"></i>
                <input type="date" name="birthdate" value="<?= $birthdate ?>" required readonly>
            </div>

            <button type="button" onclick="showConfirmation()">submit</button>
        </form>

        <div id="confirmationMessage" class="confirmation-message">
        Registration successfully confirmed!
        </div>
    </div>

    <script>
        function showConfirmation() {
            document.getElementById("confirmationMessage").style.display = "block";
        }
    </script>
</body>
</html>
