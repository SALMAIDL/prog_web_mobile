<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #121212;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #1e1e1e;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #fff;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .input-group {
            display: flex;
            align-items: center;
            background: #2a2a2a;
            border-radius: 8px;
            margin-bottom: 15px;
            padding: 10px;
        }
        .input-group i {
            color: #bbb;
            margin-right: 10px;
            font-size: 16px;
        }
        .input-group input, .input-group select {
            width: 100%;
            border: none;
            background: transparent;
            color: #ddd;
            font-size: 16px;
            outline: none;
        }
        .input-group input::placeholder {
            color: #888;
        }
        .input-group select {
            appearance: none;
            cursor: pointer;
        }
        .input-group select option {
            color: black;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #444;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            font-weight: 600;
            transition: 0.3s;
        }
        button:hover {
            background: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Register Now</h2>
        <form action="confirmation.php" method="post">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="firstname" placeholder="First Name" required>
            </div>

            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="lastname" placeholder="Last Name" required>
            </div>

            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <div class="input-group">
                <i class="fas fa-phone"></i>
                <input type="tel" name="phone" pattern="^\d{10}$" placeholder="Phone Number" required>
            </div>

            <div class="input-group">
                <i class="fas fa-venus-mars"></i>
                <select name="gender" required>
                    <option value="" disabled selected>Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="input-group">
                <i class="fas fa-calendar"></i>
                <input type="date" name="birthdate" required>
            </div>

            <button type="submit">Next</button>
        </form>
    </div>
</body>
</html>
